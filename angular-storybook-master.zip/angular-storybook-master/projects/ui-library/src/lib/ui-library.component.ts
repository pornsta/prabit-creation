import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ui-library',
  template: `
    <p>
      ui-library works!
    </p>
  `,
  styles: [
  ]
})
export class UiLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
