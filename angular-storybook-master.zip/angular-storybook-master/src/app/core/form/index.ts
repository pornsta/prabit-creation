export interface FormValueChangeEvent {
  valid: boolean;
  value: any;
}
