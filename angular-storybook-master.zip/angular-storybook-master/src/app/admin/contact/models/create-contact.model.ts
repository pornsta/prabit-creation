export interface CreateContactModel {
  username: string;
  email: string;
  name: string;
  phone: string;
}
