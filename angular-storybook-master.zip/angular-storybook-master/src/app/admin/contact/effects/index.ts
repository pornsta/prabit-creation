import { ContactEffect } from './contact.effect';

export const EFFECTS = [
  ContactEffect
];

export {
  ContactEffect
};
