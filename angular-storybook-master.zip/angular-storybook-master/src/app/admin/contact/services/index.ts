import { ContactService } from './contact.service';

export const SERVICES = [
  ContactService
];

export {
  ContactService
};
