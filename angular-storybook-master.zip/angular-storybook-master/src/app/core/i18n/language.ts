export type Language = 'en' | 'vi' | 'fr';
