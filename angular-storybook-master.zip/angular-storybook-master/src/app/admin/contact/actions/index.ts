import * as ContactActions from './contact.action';

export {
  ContactActions
};
