import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-box-form',
  templateUrl: './chat-box-form.component.html',
  styleUrls: ['./chat-box-form.component.css']
})
export class ChatBoxFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
