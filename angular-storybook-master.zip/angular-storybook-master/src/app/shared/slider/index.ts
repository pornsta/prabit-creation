export * from './slider.module';
