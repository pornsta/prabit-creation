export const i18n = {
  prefix: '/assets/i18n',
  modules: [
    'general',
    'auth',
    'account',
    'contact'
  ]
};
