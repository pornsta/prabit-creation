export const environment = {
  production: true,
  enableLogger: false,
  apiBaseUrl: 'https://angular-starter-api.herokuapp.com/',
  http: {
    maxRetryAttempts: 0
  }
};
