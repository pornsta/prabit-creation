export interface UpdateContactModel {
  id: string;
  name: string;
  phone: string;
}
