import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-box-header',
  templateUrl: './chat-box-header.component.html',
  styleUrls: ['./chat-box-header.component.scss']
})
export class ChatBoxHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
