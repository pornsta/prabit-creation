const auth = {
  expiresIn: 3600,
  tokenType: 'Bearer',
  secretKey: 'bQeThWmZq4t7w9z$'
}