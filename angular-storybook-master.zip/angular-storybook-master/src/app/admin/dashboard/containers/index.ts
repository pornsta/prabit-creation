import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';

export const CONTAINER_COMPONENTS = [
  DashboardPageComponent
];

export {
  DashboardPageComponent
};
