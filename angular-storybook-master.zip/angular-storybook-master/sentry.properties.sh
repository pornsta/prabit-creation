#!/bin/bash

authToken="<your-auth-token>"
org="<your-org>"
project="<your-project>"
release="<your-release>"
