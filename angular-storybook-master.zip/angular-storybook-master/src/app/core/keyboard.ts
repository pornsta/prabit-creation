export enum Keys {
  esc = 27,
  enter = 13,
  down = 40,
  left = 37,
  right = 39,
  up = 38
}
